# CSA U9 Boys Select — 2-3-1 Playbook

20-week progressive coaching manual for CSA U9 Boys Select.

- 2-3-1 Formation
- 20 Weeks · 40 Sessions · 60 Hours
- 4 Phases: Foundation · Development · Advanced · Mastery

Built with React + Vite.

## Run locally
```
npm install
npm run dev
```
